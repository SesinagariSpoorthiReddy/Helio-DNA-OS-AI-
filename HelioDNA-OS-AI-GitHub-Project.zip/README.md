# HelioDNA OS AI — GitHub Pages Project

This ZIP contains a standalone, GitHub Pages-ready recreation of the visible HelioDNA OS AI website.

## Important
The original website is built with Wix. Wix does not provide a normal export of a Wix Editor site as an independent source-code project. This project therefore recreates the visible content and layout as normal HTML/CSS/JavaScript.

## Files
- `index.html` — website structure/content
- `style.css` — responsive design
- `script.js` — navigation/scroll behavior

## Run locally
Open `index.html` in a browser.

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Go to Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select `main` and `/ (root)`.
6. Save. GitHub will provide the Pages URL.

## Note
Some visual elements are recreated with CSS rather than copying Wix's proprietary site files.
